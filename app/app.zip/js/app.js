angular.module('ionicApp', ['ionic'])

.controller('Messages', function($scope, $ionicScrollDelegate) {

});